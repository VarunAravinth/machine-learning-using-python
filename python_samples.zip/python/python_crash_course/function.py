def describe_pet(animal_name,animal_type='dog'):
    print 'My ' + animal_type +"'s" + ' name is '+animal_name


describe_pet(animal_name='sheldon',animal_type='hamster')
