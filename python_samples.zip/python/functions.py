





def threenewLines():
    newLine()
    newLine()
    newLine()


def newLine() :
    print    

print " One "
threenewLines()
print "two"
