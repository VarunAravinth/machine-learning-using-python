def tryone():
 return 5

print "Lets see what happens"
tryone()
    
