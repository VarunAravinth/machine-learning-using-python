import csv

with open('one.csv') as file_obj:
file_obj = csv.
