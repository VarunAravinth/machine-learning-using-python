def printasitis(varun):
    print varun, varun


printasitis("'spam'*4")
printasitis('spam'*4)
