data=[]

data.append(5)
data.append(5)

print(data)
