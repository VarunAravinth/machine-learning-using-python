def haha(self):
    return('Hello MSD')


class varun:

    
    h=haha
    trick='@company.com'

    def Method(self,name):
        self.name=name+varun.trick
        return self.name
        



x=varun()
#print(x.Method('varunAravinth'))
#print(x.h())

#y=varun()



        
