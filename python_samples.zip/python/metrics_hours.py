n=int(input("Enter total:"))
h=int(input("Enter number of inc"))

quot=int(n/h)
rem=int(n%h)

print("Check")
print("quotient=%d"%quot)
print("reminder=%d"%rem)
print("%d = %d"%(n,quot*h+rem))

      
