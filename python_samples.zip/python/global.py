

def fun():
    print(glob)

glob=1
fun()
