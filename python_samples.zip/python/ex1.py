print " Hello "
print " varun "
print " Yippe !! "
