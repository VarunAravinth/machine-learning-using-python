def oddoreven(qu):
    if qu%2==0:
        print qu," is even."
    else:
         print "%d is odd." %qu


oddoreven(56);
oddoreven(91);
#oddorven(i);
