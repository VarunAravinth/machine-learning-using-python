i=1
while i<=6:
    print 2*i,' ',
    i=i+1
print   
