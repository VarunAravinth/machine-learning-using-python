from __future__ import print_function
sample='18/07/2017 12:45:56 PM'

for ch in sample:
    print(ch,end='|')
    
    
