def power2():
    n=1
    while n<17:
       print "2^%d" %n,'\t',2**n
       n=n+1

power2()       
