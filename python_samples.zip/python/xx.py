def fun():
    x=1
    while x<5:
        print x*2,
        x+

fun()
