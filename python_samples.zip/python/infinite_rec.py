def infi():
    infi()


infi()    
