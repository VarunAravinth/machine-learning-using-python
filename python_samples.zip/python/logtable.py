def log():
    x=1.0
    print "NUMBER" ,'\t', "LOG_VALUE"
    while x<10.0:
        print x, '\t' , math.log(x)
        x=x+1.0


import math
log()
    
