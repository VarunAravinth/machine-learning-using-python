def twotable():
    n=1
    while n<5:
        print n*2,
        n=n+1
    print
twotable()
