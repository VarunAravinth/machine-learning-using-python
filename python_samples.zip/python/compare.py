def compare(x,y):
    if (x>y):
        return 1
    if(x==y):
        return 0
    if(x<y):
        return -1

one=compare(5,6)
two=compare(89,78)
three=compare(78,78)

print " comparing 5 and 6 ",one
print " comparing 89 and 78 ",two
print " comparing 78 adn 78 ",three

    
        
